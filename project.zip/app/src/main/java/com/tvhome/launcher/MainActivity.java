package com.tvhome.launcher;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {
    private WebView web;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.setBackgroundColor(0xFF0A0C12);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "Native");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        web.requestFocus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) {
            web.evaluateJavascript("if(typeof refresh==='function')refresh();", null);
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (web != null) {
            web.evaluateJavascript("if(typeof goHome==='function')goHome();", null);
        }
    }

    @Override
    public void onBackPressed() {
        // Launcher: back dabane par kuch nahi hota
    }

    private String iconB64(Drawable d) {
        try {
            Bitmap bm = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888);
            Canvas cv = new Canvas(bm);
            d.setBounds(0, 0, 96, 96);
            d.draw(cv);
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            bm.compress(Bitmap.CompressFormat.PNG, 100, bo);
            return Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP);
        } catch (Exception e) {
            return "";
        }
    }

    class Bridge {
        @JavascriptInterface
        public String getApps() {
            JSONArray out = new JSONArray();
            try {
                PackageManager pm = getPackageManager();
                Set<String> seen = new HashSet<String>();
                List<JSONObject> items = new ArrayList<JSONObject>();
                String[] cats = {Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER};
                for (String c : cats) {
                    Intent i = new Intent(Intent.ACTION_MAIN);
                    i.addCategory(c);
                    for (ResolveInfo r : pm.queryIntentActivities(i, 0)) {
                        String p = r.activityInfo.packageName;
                        if (p.equals(getPackageName()) || !seen.add(p)) continue;
                        JSONObject o = new JSONObject();
                        o.put("name", String.valueOf(r.loadLabel(pm)));
                        o.put("pkg", p);
                        o.put("icon", iconB64(r.loadIcon(pm)));
                        items.add(o);
                    }
                }
                Collections.sort(items, new Comparator<JSONObject>() {
                    public int compare(JSONObject a, JSONObject b) {
                        return a.optString("name").compareToIgnoreCase(b.optString("name"));
                    }
                });
                for (JSONObject o : items) out.put(o);
                JSONObject st = new JSONObject();
                st.put("name", "Settings");
                st.put("pkg", "::settings");
                st.put("icon", "");
                out.put(st);
            } catch (Exception e) {
            }
            return out.toString();
        }

        @JavascriptInterface
        public void launch(final String pkg) {
            runOnUiThread(new Runnable() {
                public void run() {
                    try {
                        if ("::settings".equals(pkg)) {
                            Intent si = new Intent(Settings.ACTION_SETTINGS);
                            si.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(si);
                            return;
                        }
                        Intent i = getPackageManager().getLeanbackLaunchIntentForPackage(pkg);
                        if (i == null) i = getPackageManager().getLaunchIntentForPackage(pkg);
                        if (i != null) startActivity(i);
                    } catch (Exception e) {
                    }
                }
            });
        }
    }
}
